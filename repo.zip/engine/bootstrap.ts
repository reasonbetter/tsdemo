// engine/bootstrap.ts
let BOOTSTRAPPED = false;

/** Import-time registration lives in engine/drivers/index.ts */
export async function ensureDriverRegistryBootstrapped(): Promise<void> {
  if (BOOTSTRAPPED) return;
  // Dynamic import prevents circular import issues and plays well with HMR
  await import("@/engine/drivers");
  BOOTSTRAPPED = true;
}
