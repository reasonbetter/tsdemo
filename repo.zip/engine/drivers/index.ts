// engine/drivers/index.ts
import { registerDriver, setDefaultDriverForKind } from "@/engine/registry";

// Import the concrete drivers
import { AlternativeExplanationGenerationDriver } from "@/engine/drivers/AlternativeExplanationGeneration";
import { GenericNumericDriver } from "@/engine/drivers/GenericNumeric";

// Register
registerDriver(AlternativeExplanationGenerationDriver);
registerDriver(GenericNumericDriver);

// Optional defaults (so schemas can specify Engine.kind instead of driverId)
setDefaultDriverForKind("aeg", AlternativeExplanationGenerationDriver.id);
setDefaultDriverForKind("generic.numeric", GenericNumericDriver.id);
