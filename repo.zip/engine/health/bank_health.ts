// engine/health/bank_health.ts
import fs from "fs/promises";
import path from "path";
import type { ItemEnvelope, SchemaEnvelope } from "@/types/kernel";
import { inspectSchemasAndItems } from "@/engine/kernel/validation";

async function safeReadDir(dir: string): Promise<string[]> {
  try {
    return (await fs.readdir(dir)).filter(n => n.endsWith(".json"));
  } catch (e) {
    console.warn(`Health check: Could not read directory ${dir}`, e);
    return [];
  }
}

export async function inspectBankHealth() {
  const schemaDir = path.join(process.cwd(), "data/schemas");
  const itemDir   = path.join(process.cwd(), "data/items");

  const schemaFiles = await safeReadDir(schemaDir);
  const itemFiles   = await safeReadDir(itemDir);

  type Load<T> = { file: string; entity?: T; parseError?: string };

  const schemaLoads: Load<SchemaEnvelope>[] = [];
  const itemLoads: Load<ItemEnvelope>[] = [];

  // Parse schemas
  for (const f of schemaFiles) {
    try {
      const content = await fs.readFile(path.join(schemaDir, f), "utf8");
      schemaLoads.push({ file: f, entity: JSON.parse(content) });
    } catch (e: any) {
      schemaLoads.push({ file: f, parseError: `JSON Parse Error: ${e?.message ?? e}` });
    }
  }

  // Parse items
  for (const f of itemFiles) {
    try {
      const content = await fs.readFile(path.join(itemDir, f), "utf8");
      itemLoads.push({ file: f, entity: JSON.parse(content) });
    } catch (e: any) {
      itemLoads.push({ file: f, parseError: `JSON Parse Error: ${e?.message ?? e}` });
    }
  }

  // Validate the successfully parsed entities
  const schemas = schemaLoads.map(s => s.entity).filter(Boolean) as SchemaEnvelope[];
  const items   = itemLoads.map(i => i.entity).filter(Boolean) as ItemEnvelope[];

  const { schemaResults, itemResults } = inspectSchemasAndItems(schemas, items);

  // Add parse errors as separate rows
  const schemaParseRows = schemaLoads
    .filter(s => s.parseError)
    .map(s => ({ schemaId: s.file, ok: false, error: s.parseError! }));

  const itemParseRows = itemLoads
    .filter(i => i.parseError)
    .map(i => ({ itemId: i.file, schemaId: "<unknown>", ok: false, error: i.parseError! }));

  return {
    counts: { schemas: schemaLoads.length, items: itemLoads.length },
    schemaResults: [...schemaParseRows, ...schemaResults],
    itemResults:   [...itemParseRows,   ...itemResults],
  };
}
