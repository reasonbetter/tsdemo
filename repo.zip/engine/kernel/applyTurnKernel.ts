/* engine/kernel/applyTurnKernel.ts */
import { deepMerge } from "@/engine/utils/deepMerge";
import { ensureAJPrimed } from "./priming";
import { resolveDriver } from "@/engine/registry";
import { validateAjOutputOrThrow } from "./validation";
import { enforceProbePolicy } from "./probe_policy";
import { thetaService } from "@/engine/services/theta";
import type {
  ItemEnvelope, SchemaEnvelope, SessionSnapshot, Json,
  UnitStateEnvelope, ThetaState, DriverDecision, ScorePayload
} from "@/types/kernel";
import { loadBank, getSchemaById, getItemById } from "@/lib/bank";

/* Deterministic RNG (xorshift32) seeded by string */
function seededRng(seedStr: string): () => number {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < seedStr.length; i++) { h ^= seedStr.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
  let x = h || 0x9e3779b9;
  return () => { x ^= x << 13; x >>>= 0; x ^= x >>> 17; x >>>= 0; x ^= x << 5; x >>>= 0; return (x >>> 0) / 0xffffffff; };
}

/* Resolve primary ability key */
function abilityKeyOf(schema: SchemaEnvelope): string {
  const a = schema.Ability ?? {};
  if (a.key) return a.key;
  if (Array.isArray(a.keys) && a.keys.length > 0) return a.keys[0]!;
  return "global";
}

/* Wrap legacy/new driver payload into a UnitStateEnvelope (kernel owns meta) */
function toEnvelope(
  rawState: any,
  schema: SchemaEnvelope,
  item: ItemEnvelope,
  driverId: string,
  driverVersion: string
): UnitStateEnvelope {
  if (rawState && typeof rawState === "object" && "meta" in rawState && "payload" in rawState) {
    return rawState as UnitStateEnvelope;
  }
  return {
    meta: {
      driverId,
      driverVersion,
      contractVersion: schema.GuidanceVersion,
      schemaId: schema.SchemaID,
      itemId: item.ItemID,
      abilityKey: abilityKeyOf(schema),
      startedAtMs: Date.now(),
      turnCount: 0,
      attempts: 0,
      consecutiveUnproductive: 0,
    },
    payload: rawState ?? {},
  };
}

/* ---- Kernel turn entry point ------------------------------------------- */
export async function applyTurnKernel(params: {
  session: SessionSnapshot;
  sessionPersist?: (s: SessionSnapshot) => Promise<void>;
  schemaId: string;
  itemId: string;
  userText: string;
  ajRaw: unknown;
}) {
  const { session } = params;

  // 1) Load schema & item
  const bank = await loadBank();
  const schema = getSchemaById(bank, params.schemaId) as SchemaEnvelope;
  const item   = getItemById(bank, params.itemId) as ItemEnvelope;

  // 2) Prime AJ once per (driver, GuidanceVersion)
  await ensureAJPrimed(session, schema, item);

  // 3) Resolve driver & thin merges
  const driver = resolveDriver(schema.Engine ?? {});
  const policy  = deepMerge((schema as any).PolicyDefaults ?? {}, (item as any).DriverOverrides?.Policy ?? {},  { arrayStrategy: "replace" });
  const scoring = deepMerge((schema as any).ScoringSpec     ?? {}, (item as any).DriverOverrides?.Scoring ?? {}, { arrayStrategy: "replace" });

  // 4) Kernel budgets
  const timeBudgetSec = Number((policy as any).TimeBudgetSec ?? 120);
  const maxConsecFail = Number((policy as any).MaxConsecutiveFailedAttempts ?? 2);

  // 5) Ensure envelope state for this unit
  const abilityKey = abilityKeyOf(schema);
  if (!session.unit || session.unit.completed || session.unit.driverId !== driver.id) {
    const initPayload = driver.initUnitState(schema, item);
    session.unit = { driverId: driver.id, state: toEnvelope(initPayload, schema, item, driver.id, driver.version), completed: false };
  }
  const env = toEnvelope(session.unit.state, schema, item, driver.id, driver.version) as UnitStateEnvelope;

  // Kernel-owned meta counters
  env.meta.turnCount = (env.meta.turnCount ?? 0) + 1;
  if (env.meta.attempts == null) env.meta.attempts = 0;
  if (env.meta.consecutiveUnproductive == null) env.meta.consecutiveUnproductive = 0;

  // 6) Time bookkeeping
  const startedAt = env.meta.startedAtMs ?? Date.now();
  const elapsedMs = Date.now() - startedAt;

  // 7) Validate AJ contract (Safety Catch)
  let ajValidated: any = null;
  let ajValidationError: Error | null = null;
  try { validateAjOutputOrThrow(schema, params.ajRaw); ajValidated = params.ajRaw; } catch (err: any) { ajValidationError = err; }

  // 8) Deterministic RNG
  const rng = seededRng(`${session.id}:${driver.id}:${item.ItemID}:${env.meta.turnCount}`);

  // 9) Driver decision
  let decision: DriverDecision<Json>;
  if (ajValidationError) {
    decision = {
      credited: 0,
      score: { value: 0, label: "aj_contract_invalid" },
      budgetSignal: "unproductive",
      probe: { id: null, text: "I couldn’t parse that—please answer in the expected format.", category: "format" },
      uiBadges: ["AJ Contract: Invalid"],
      completed: false,
      telemetry: { error: String(ajValidationError.message) },
      newState: env.payload,
      error_code: "AJ_SCHEMA_INVALID",
    };
  } else {
    const ajParsed = driver.parseAJOutput(ajValidated, schema, item);
    decision = driver.applyTurn({
      schema, item,
      unitState: env.payload as any,
      aj: ajParsed as any,
      userText: params.userText,
      policy: policy as any,
      scoring: scoring as any,
      rng,
    });
  }

  // 10) Kernel budget counters (persisted in envelope meta)
  env.meta.attempts! += 1;
  if (decision.budgetSignal === "unproductive") {
    env.meta.consecutiveUnproductive! += 1;
  } else if (decision.budgetSignal === "productive") {
    env.meta.consecutiveUnproductive = 0;
  }
  // 'neutral' leaves streak as-is

  const timeExpired = elapsedMs > timeBudgetSec * 1000;
  const failExceeded = (env.meta.consecutiveUnproductive ?? 0) >= maxConsecFail;
  const domainDone = !!decision.completed;
  const completed = domainDone || timeExpired || failExceeded;

  // 11) Θ update (central)
  const score: ScorePayload = decision.score ?? { value: Math.max(0, Number(decision.credited) || 0), label: "legacy_credited" };
  const theta: ThetaState = thetaService.update(session.theta, abilityKey, score, scoring);

  // 12) Sanitize AJ-generated probe per schema policy
  const policyCheck = enforceProbePolicy(schema, decision.probe ?? null);

  // 13) Persist session snapshot (envelope carries budgets)
  const newEnv: UnitStateEnvelope = { meta: { ...env.meta }, payload: decision.newState };
  session.theta = theta;
  session.unit = { driverId: driver.id, state: newEnv as any, completed };
  if (params.sessionPersist) await params.sessionPersist(session);

  // 14) Response
  return {
    credited: decision.credited,
    score,
    uiBadges: decision.uiBadges ?? [],
    probe: policyCheck.probe,
    theta,
    completed,
    telemetry: {
      ...decision.telemetry,
      error_code: decision.error_code ?? null,
      ability_key: abilityKey,
      attempts: newEnv.meta.attempts ?? 0,
      consecutive_unproductive: newEnv.meta.consecutiveUnproductive ?? 0,
      time_elapsed_ms: elapsedMs,
      time_expired: timeExpired,
      fail_exceeded: failExceeded,
      domain_done: domainDone,
      aj_probe_blocked: policyCheck.blocked,
      aj_probe_truncated: policyCheck.truncated,
      aj_probe_reason: policyCheck.reason ?? null,
    },
    unitState: newEnv,
  };
}
