/* engine/services/theta.ts */
import type { Json, ScorePayload, ThetaComponent, ThetaState } from "@/types/kernel";

export interface ThetaService {
  update(theta: ThetaState, abilityKey: string, score: ScorePayload | { value: number }, scoringSpec: Json): ThetaState;
  get(theta: ThetaState, abilityKey: string): ThetaComponent;
  set(theta: ThetaState, abilityKey: string, comp: ThetaComponent): ThetaState;
}

const DEFAULT_STEP = 0.25;
const DEFAULT_VAR_DECAY = 0.9;
const DEFAULT_MIN_VAR = 0.5;

function ensure(theta: ThetaState): ThetaState {
  return theta?.dims ? theta : { dims: {} };
}

function get(theta: ThetaState, key: string): ThetaComponent {
  const t = ensure(theta);
  return t.dims[key] ?? { mean: 0, var: 1 };
}

function set(theta: ThetaState, key: string, comp: ThetaComponent): ThetaState {
  const t = ensure(theta);
  return { dims: { ...t.dims, [key]: comp } };
}

export const thetaService: ThetaService = {
  update(theta, abilityKey, scoreLike, scoringSpec) {
    const value = typeof (scoreLike as any).value === "number" ? (scoreLike as any).value : Number(scoreLike) || 0;

    // Pull optional knobs from scoringSpec.theta
    const thetaSpec = (scoringSpec as any)?.theta ?? {};
    const step = Number(thetaSpec.step ?? DEFAULT_STEP);
    const varDecay = Math.max(0, Math.min(1, Number(thetaSpec.varDecay ?? DEFAULT_VAR_DECAY)));
    const minVar = Number(thetaSpec.minVar ?? DEFAULT_MIN_VAR);

    const cur = get(theta, abilityKey);
    const mean = cur.mean + step * value;
    const variance = Math.max(minVar, cur.var * varDecay);
    return set(theta, abilityKey, { mean, var: variance });
  },
  get,
  set,
};
