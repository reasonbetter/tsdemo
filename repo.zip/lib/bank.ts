import fs from "fs/promises";
import path from "path";
import type { SchemaEnvelope, ItemEnvelope } from "@/types/kernel";
import { validateSchemasAndItemsOrThrow } from "@/engine/kernel/validation";

export interface Bank {
  schemas: Record<string, SchemaEnvelope>;
  items: ItemEnvelope[];
}

export function getSchemaById(bank: Bank, id: string): SchemaEnvelope {
  const s = bank.schemas[id];
  if (!s) throw new Error(`Schema '${id}' not found`);
  return s;
}
export function getItemById(bank: Bank, id: string): ItemEnvelope {
  const it = bank.items.find(i => i.ItemID === id);
  if (!it) throw new Error(`Item '${id}' not found`);
  return it;
}

export async function loadBank(): Promise<Bank> {
  const schemaDir = path.join(process.cwd(), "data/schemas");
  const itemDir   = path.join(process.cwd(), "data/items");

  const schemaFiles = (await fs.readdir(schemaDir)).filter(n => n.endsWith(".json"));
  const itemFiles   = (await fs.readdir(itemDir)).filter(n => n.endsWith(".json"));

  const schemasArr: SchemaEnvelope[] = [];
  for (const f of schemaFiles) {
    const j = JSON.parse(await fs.readFile(path.join(schemaDir, f), "utf8"));
    schemasArr.push(j);
  }

  const items: ItemEnvelope[] = [];
  for (const f of itemFiles) {
    const j = JSON.parse(await fs.readFile(path.join(itemDir, f), "utf8"));
    items.push(j);
  }

  // Validate envelopes + compile AJ contracts (throws on failure)
  validateSchemasAndItemsOrThrow(schemasArr, items);

  const schemas: Record<string, SchemaEnvelope> = Object.fromEntries(schemasArr.map(s => [s.SchemaID, s]));
  return { schemas, items };
}
