import type { NextApiRequest, NextApiResponse } from "next";
import { ensureDriverRegistryBootstrapped } from "@/engine/bootstrap";
import { registryHealth } from "@/engine/registry";
import { inspectBankHealth } from "@/engine/health/bank_health";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "GET") return res.status(405).json({ ok: false, error: "Method not allowed" });

  await ensureDriverRegistryBootstrapped();

  const drivers = registryHealth();
  const bank = await inspectBankHealth();

  return res.status(200).json({
    ok: true,
    drivers,
    bank
  });
}
